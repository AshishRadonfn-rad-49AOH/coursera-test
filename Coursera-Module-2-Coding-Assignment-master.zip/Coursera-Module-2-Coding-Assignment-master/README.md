Welcome, this is my Coursera Module2 Coding Assignment.
